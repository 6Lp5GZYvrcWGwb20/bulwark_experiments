tinyMCE.addI18n('cy.paste_dlg',{
text_title:"Defnyddiwch CTRL+V ar eich bysellfwrdd i ludo'r testun i fewn i'r ffenest.",
text_linebreaks:"Cadw toriadau llinell",
word_title:"Defnyddiwch CTRL+V ar eich bysellfwrdd i ludo'r testun i fewn i'r ffenest."
});